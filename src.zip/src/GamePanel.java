import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.*;
import javax.swing.border.EtchedBorder;

public class GamePanel extends JPanel implements ActionListener, KeyListener,
		MouseListener, MouseMotionListener {

	public GamePanel() {
		tm.start();
		addKeyListener(this);
		addMouseListener(this);
		addMouseMotionListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		setSize(Main.lengthOfFrame, Main.heightOfFrame - StatisticPanel.height);
		setBackground(Color.BLACK);
		teamNumber.add(team1);
		teamNumber.add(team2);
		teamNumber.add(team3);
		teamNumber.add(team4);
	}

	Terrain terrain = new Terrain();
	Structures structures = new Structures();
	ArrayList<Team> teamNumber = new ArrayList<Team>();
	ArrayList<Unit> allTroops = new ArrayList<Unit>();

	// Game conditions
	// Kills
	int kill = -1;
	int killLimit = 0;

	// Deaths
	int death = -1;
	int deathLimit = 0;

	// Spawned
	int spawn = -1;
	int spawnLimit = 0;

	{
		// Kill limit or not
		kill = JOptionPane.showConfirmDialog(null,
				"Do you want a kill number?", "Reset",
				JOptionPane.YES_NO_OPTION);
		if (kill == JOptionPane.YES_OPTION) {
			killLimit = Integer.parseInt(JOptionPane
					.showInputDialog("Pick the kill number."));
		}

		// Death limit or not
		death = JOptionPane.showConfirmDialog(null,
				"Do you want a death limit?", "Reset",
				JOptionPane.YES_NO_OPTION);
		if (death == JOptionPane.YES_OPTION) {
			deathLimit = Integer.parseInt(JOptionPane
					.showInputDialog("Pick the death limit."));
		}

		// Spawn limit or not
		spawn = JOptionPane.showConfirmDialog(null,
				"Do you want a spawn limit?", "Reset",
				JOptionPane.YES_NO_OPTION);

		if (spawn == JOptionPane.YES_OPTION) {
			spawnLimit = Integer.parseInt(JOptionPane
					.showInputDialog("Pick the spawn limit."));
		}

		
	}

	String pop = JOptionPane.showInputDialog("Set the Maximum Population");
	int popLimiter = Integer.parseInt(pop);

	Team team1 = new Team(Color.RED, KeyEvent.VK_1, 0, popLimiter);
	Team team2 = new Team(Color.YELLOW, KeyEvent.VK_B, 1, popLimiter);
	Team team3 = new Team(Color.MAGENTA, KeyEvent.VK_X, 2, popLimiter);
	Team team4 = new Team(Color.GREEN, KeyEvent.VK_SLASH, 3, popLimiter);

	Timer tm = new Timer(10, this);

	int mouseX = 0;
	int mouseY = 0;
	int boxX = 0;
	int boxY = 0;
	int mouseWidth = 0;
	int mouseHeight = 0;
	boolean firstClick = true;
	boolean pause = false;

	// ======================================PAINT-COMPONENT==========================================================//
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.setColor(Color.BLUE);
		g.fillRect(0, Main.heightOfFrame - StatisticPanel.height,
				Main.lengthOfFrame, 100);
		g.setColor(Color.WHITE);
		g.drawString("Running: " + pause, 900, 610);
		g.drawRect(boxX, boxY, mouseWidth, mouseHeight);
		g.drawString("Kill Limit: " + killLimit, 900, 610 + 12);
		g.drawString("Death Limit: " + deathLimit, 900, 610 + 24);
		g.drawString("Spawn Limit: " + spawnLimit, 900, 610 + 36);
		g.drawString("Pop Limit: " + popLimiter, 900, 610 + 48);

		structures.paint(g);
		terrain.draw(g);
		for (Team team : teamNumber) {
			team.paint(g, teamNumber);
		}
		repaint();
	}

	public void resetEverything() {
		for (Team t : teamNumber) {
			t.fullReset();
		}
		
		structures.reset();
		
		terrain.reset();
		int reset = JOptionPane.showConfirmDialog(null, "Reset rules?",
				"Reset", JOptionPane.YES_NO_OPTION);

		if (reset == JOptionPane.YES_OPTION) {
			// Kill limit or not
			kill = JOptionPane.showConfirmDialog(null,
					"Do you want a kill number?", "Reset",
					JOptionPane.YES_NO_OPTION);
			if (kill == JOptionPane.YES_OPTION) {
				killLimit = Integer.parseInt(JOptionPane
						.showInputDialog("Pick the kill number."));
			}

			// Death limit or not
			death = JOptionPane.showConfirmDialog(null,
					"Do you want a death limit?", "Reset",
					JOptionPane.YES_NO_OPTION);
			if (death == JOptionPane.YES_OPTION) {
				deathLimit = Integer.parseInt(JOptionPane
						.showInputDialog("Pick the death limit."));
			}

			// Spawn limit or not
			spawn = JOptionPane.showConfirmDialog(null,
					"Do you want a spawn limit?", "Reset",
					JOptionPane.YES_NO_OPTION);

			if (spawn == JOptionPane.YES_OPTION) {
				spawnLimit = Integer.parseInt(JOptionPane
						.showInputDialog("Pick the spawn limit."));
			}

			pop = JOptionPane.showInputDialog("Set the Maximum Population");
			popLimiter = Integer.parseInt(pop);
			for (Team t : teamNumber) {
				t.changePop(popLimiter);
			}
		}
	}

	// Moving and spawning for team Builders
	public void keyPressed(KeyEvent e) {
		for (Team t : teamNumber) {
			boolean canType = true;
			if (spawn == JOptionPane.YES_OPTION) {
				if (t.totalSpawned > spawnLimit) {
					canType = false;
				}
			}
			if (canType) {
				t.keyPr(e);
			}
		}
	}

	public void keyReleased(KeyEvent e) {

		// Moving and spawning for team Builders
		for (Team t : teamNumber) {
			boolean canType = true;
			if (spawn == JOptionPane.YES_OPTION) {
				if (t.totalSpawned > spawnLimit) {
					canType = false;
				}
			}
			if ((canType) && (t.teamHasDied == false)) {
				t.keyRe(e, t.key0);
			}
		}

		// Reset button (doesn't reset Builder locations)
		if (e.getKeyCode() == KeyEvent.VK_SPACE) {
			pause = false;

			int fullReset = -1;
			fullReset = JOptionPane.showConfirmDialog(null,
					"Do you want a full reset?", "Reset",
					JOptionPane.YES_NO_OPTION);
			if (fullReset == JOptionPane.NO_OPTION) {

				int i = 1;
				int answer = -1;
				answer = JOptionPane.showConfirmDialog(null,
						"Do you want to reset troops?", "Reset", i,
						JOptionPane.YES_NO_OPTION);
				int nextAnswer = -1;
				nextAnswer = JOptionPane.showConfirmDialog(null,
						"Do you want to reset the terrain?", "Reset", i,
						JOptionPane.YES_NO_OPTION);
				if (answer == JOptionPane.YES_OPTION) {

					for (Team t : teamNumber) {
						t.reset();
					}
					structures.reset();

				}
				if (nextAnswer == JOptionPane.YES_OPTION) {
					terrain.reset();
				}
			} else if (fullReset == JOptionPane.YES_OPTION) {
				resetEverything();
			}
		}

		// Pause button
		if (e.getKeyCode() == KeyEvent.VK_P) {
			if (pause) {
				pause = false;
			} else {
				pause = true;
			}
		}
	}

	public void keyTyped(KeyEvent e) {
	}

	public void mouseClicked(MouseEvent e) {
		terrain.mouseClick(e);
	}

	public void mouseEntered(MouseEvent e) {

	}

	public void mouseExited(MouseEvent e) {

	}

	public void mousePressed(MouseEvent e) {
		terrain.mousePress(e);
		if (firstClick) {
			mouseX = e.getX();
			mouseY = e.getY();
			firstClick = false;
		}
	}

	public void mouseReleased(MouseEvent e) {
		terrain.mouseRel(e, pause);
		firstClick = true;
		mouseX = mouseY = boxX = boxY = mouseWidth = mouseHeight = 0;
	}

	// Actions performed!
	public void actionPerformed(ActionEvent e) {

		structures.actionPer(allTroops);

		for (Team t : teamNumber) {
			if (allTroops.containsAll(t.totalTroops)) {
			} else {
				allTroops.removeAll(t.totalTroops);
				allTroops.addAll(t.totalTroops);
			}
		}

		if (allTroops.isEmpty()) {
		} else {
			try {
				for (Unit i : allTroops) {
					if (i != null) {
						if (i.health <= 0) {
							allTroops.remove(allTroops.indexOf(i));
						}
					} else {
						allTroops.remove(allTroops.indexOf(i));
					}
				}
			} catch (Exception e1) {
			}
		}

		

		// Terrain
		terrain.actionHit(e);

		int teamsAlive = 4;

		// Controls for Builder box
		for (Team t : teamNumber) {

			// Win by kills
			if (kill == JOptionPane.YES_OPTION) {
				if (t.totalKills >= killLimit) {
					JOptionPane.showMessageDialog(null, "Player "
							+ t.colorOfTeam + " won!");
					resetEverything();
				}
			}

			// Loss by deaths
			if (death == JOptionPane.YES_OPTION) {
				if ((t.totalDeaths >= deathLimit) || (t.teamHasDied)) {
					t.hasDied();
					t.reset();
					teamsAlive--;
				}
			}
			if (t.teamHasDied == false) {
				t.actionBuilder(e);
				if ((teamsAlive == 1)) {
				}
			}
			if ((teamsAlive == 1) && (t.teamHasDied == false)) {
				JOptionPane.showMessageDialog(null, "Player " + t.colorOfTeam
						+ " won!");
				resetEverything();
			}
		}

		if (pause) {
			// Controls for Units
			for (Team t : teamNumber) {
				if (t.teamHasDied == false) {
					t.actionPer(e, teamNumber, terrain.totalObstructions,
							structures.totalBuildings);
				}
			}
		}
	}

	public void mouseDragged(MouseEvent e) {
		if (mouseX < e.getX()) {
			boxX = mouseX;
		} else {
			boxX = e.getX();
		}
		if (mouseY < e.getY()) {
			boxY = mouseY;
		} else {
			boxY = e.getY();
		}
		mouseWidth = Math.abs(mouseX - e.getX());
		mouseHeight = Math.abs(mouseY - e.getY());
	}

	public void mouseMoved(MouseEvent e) {
	}
}
