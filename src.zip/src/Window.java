import javax.swing.*;

import java.awt.*;

public class Window extends JFrame {

	public Window() {

		super.setTitle("RTS");
		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}
}
