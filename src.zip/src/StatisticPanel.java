
import java.awt.Color;
import java.awt.Graphics;

import javax.swing.*;

public class StatisticPanel extends JPanel{
	public static int height = 120;
	public StatisticPanel(){
		setSize(1200,100);
		setBackground(Color.BLUE);
		setVisible(true);
	}
	
	
}
